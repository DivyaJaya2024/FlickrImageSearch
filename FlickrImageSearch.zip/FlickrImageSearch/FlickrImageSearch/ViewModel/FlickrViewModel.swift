//
//  FlickrViewModel.swift
//  FlickrImageSearch
//
//  Created by divyaj on 11/19/24.
//

import Foundation
import Combine

class FlickrViewModel: ObservableObject {
    
    @Published var images: [FlickrModel] = []
    @Published var isLoading: Bool = false
    @Published var errorMesssage: String?
    @Published var searchQuery: String = "" {
        didSet {
            searchImages()
        }
    }
    
    // Function to fetch images from the API
    func searchImages() {
        
        errorMesssage = nil
        guard !searchQuery.isEmpty else { return }
        
        // Update loading state
        isLoading = true

        let urlString = "https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=\(searchQuery.replacingOccurrences(of: " ", with: ","))"
        
        guard let url = URL(string: urlString) else {
            errorMesssage = "Invalid URL"
            self.isLoading = false
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data, error == nil {
                if let result = try? JSONDecoder().decode(FlickrResponse.self, from: data) {
                    DispatchQueue.main.async {
                        self.images = result.items
                        self.isLoading = false
                    }
                } else {
                    DispatchQueue.main.async {
                        self.isLoading = false
                        self.errorMesssage = "No Images"

                    }
                }
            }
        }.resume()
    }
}
