//
//  FlickrModel.swift
//  FlickrImageSearch
//
//  Created by divyaj on 11/19/24.
//

import Foundation

struct FlickrModel: Codable {
    let title: String
    let description: String
    let author: String
    let published: String
    let media: Media

    struct Media: Codable {
        let m: String
    }
}

struct FlickrResponse: Codable {
    var items: [FlickrModel]
}
