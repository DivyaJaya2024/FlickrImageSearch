//
//  FlickrView.swift
//  FlickrImageSearch
//
//  Created by divyaj on 11/19/24.
//

import SwiftUI

struct FlickrView: View {
    @StateObject private var viewModel = FlickrViewModel()

    var body: some View {
        
        NavigationView {
            
            VStack {
                // Search Bar
                TextField("Search for images...", text: $viewModel.searchQuery)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(height: 40)
                .accessibilityIdentifier("Search")
                // Loading Indicator
                if viewModel.isLoading {
                ProgressView("Loading...")
                    .progressViewStyle(CircularProgressViewStyle())
                }
                if let errorMessage = viewModel.errorMesssage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                // Image Grid
                ScrollView {
                    
                    if !viewModel.isLoading {
                        
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150))], spacing: 10) {
                            ForEach(0..<viewModel.images.count, id: \.self) { index in
                                    NavigationLink(destination: DetailFlickrView(fm: viewModel.images[index])) {
                                        ImageThumbnailView(image: viewModel.images[index])
                                        
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
           .navigationTitle("Flickr Image Search")
       }
    }
}
struct ImageThumbnailView: View {
    var image: FlickrModel
    
    var body: some View {
        AsyncImage(url: URL(string: image.media.m)) { phase in
            switch phase {
            case .success(let image):
                image.resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
            case .failure:
                Color.gray.frame(width: 150, height: 150)
            case .empty:
                Color.gray.frame(width: 150, height: 150)
            default:
                fatalError()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

#Preview {
    FlickrView()
}
