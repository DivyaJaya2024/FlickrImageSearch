//
//  DetailFlickrView.swift
//  FlickrImageSearch
//
//  Created by divyaj on 11/19/24.
//

import SwiftUI
import WebKit

// Display HTML Content

struct HTMLTextView: UIViewRepresentable {
    var htmlContent: String
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.loadHTMLString(htmlContent, baseURL: nil)
    }
}

struct DetailFlickrView: View {
    var fm: FlickrModel
    
    // Computed property to extract just the author's name
    var authorName: String {
        // Regular expression to match the author's name inside parentheses
        let regex = try? NSRegularExpression(pattern: "\\(\"([^\"]+)\"\\)", options: [])
        let range = NSRange(location: 0, length: fm.author.utf16.count)
        
        if let match = regex?.firstMatch(in: fm.author, options: [], range: range) {
            if let authorRange = Range(match.range(at: 1), in: fm.author) {
                // Extract the name inside the parentheses
                return String(fm.author[authorRange])
            }
        }
        
        // If no match, return the full author string
        return fm.author
    }
    
    var body: some View {
        VStack {
            // Image
            AsyncImage(url: URL(string: fm.media.m)) { image in
                image.resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 400)
                    .cornerRadius(12)
                    .padding()
            } placeholder: {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle())
                    .padding()
            }
            
            // Title
            Text(fm.title)
                .font(.title)
                .bold()
                .padding([.top, .horizontal])
                .fixedSize()
                .lineLimit(2)
            
            // Description
            HTMLTextView(htmlContent: fm.description)
                .padding([.horizontal])
                .frame(maxHeight: 300)
            
            // Author
            Text("Author: \(String(describing: authorName))")
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.bottom)
            
            // Published Date
            Text("Published: \(formattedDate(fm.published))")
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.bottom)

        }
        .navigationTitle("Detail Flickr Image")
        .background(Color(UIColor.systemGroupedBackground))
        .cornerRadius(12)
        .padding()
    }
    
    // Helper function to format the published date
    private func formattedDate(_ dateString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
        
        guard let date = formatter.date(from: dateString) else { return "Unknown" }
        
        // Now convert to a more readable format
        let displayFormatter = DateFormatter()
        displayFormatter.dateStyle = .medium
        displayFormatter.timeStyle = .short
        
        return displayFormatter.string(from: date)
    }
}

struct DetailFlickrView_Previews: PreviewProvider {
    static var previews: some View {
        // Sample preview with dummy data
        DetailFlickrView(fm: FlickrModel(
            title: "Cute Porcupine",
            description: "This is a cute porcupine in the wild.",
            author: "John Doe",
            published: "2024-10-25T15:42:00Z",
            media: FlickrModel.Media(m: "https://www.example.com/photo.jpg")
        ))
    }
}

