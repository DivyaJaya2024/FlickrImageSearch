//
//  FlickrImageSearchApp.swift
//  FlickrImageSearch
//
//  Created by divyaj on 11/19/24.
//

import SwiftUI

@main
struct FlickrImageSearchApp: App {
    var body: some Scene {
        WindowGroup {
            FlickrView()
        }
    }
}
