//
//  FlickrImageSearchTests.swift
//  FlickrImageSearchTests
//
//  Created by divyajayaseelan on 11/19/24.
//

import XCTest
@testable import FlickrImageSearch

final class FlickrImageSearchTests: XCTestCase {
    var viewModel: FlickrViewModel!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        viewModel = FlickrViewModel()

    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        viewModel = nil

    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }
    
    func testFetchImagesSuccess() {
        // Perform the fetch operation
        viewModel.searchQuery = "Pa"
        viewModel.searchImages()
        
     // Simulate a delay to allow the error handling to take place
        let expectation = self.expectation(description: "Waiting for error")
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            XCTAssertNotEqual(self.viewModel.images.count, 0)
            XCTAssertFalse(self.viewModel.isLoading)
            XCTAssertEqual(self.viewModel.errorMesssage, nil)
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 3, handler: nil)
    }
    
    func testEmptySearchQuery() {
        // Search with an empty query should not trigger a network request
        viewModel.searchQuery = ""
        viewModel.searchImages()
        // Assert that no images are returned and no request is made
        XCTAssertEqual(viewModel.images.count, 0)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(self.viewModel.errorMesssage, nil)

    }
}
